// app/(dashboard)/admin/page.tsx
"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { 
  Users, 
  GraduationCap, 
  BookOpen, 
  Plus, 
  Edit, 
  Trash2, 
  CheckCircle, 
  XCircle,
  Search,
  X,
  Save,
  Eye,
  EyeOff,
  LogOut,
  ChevronLeft,
  ChevronRight,
  AlertCircle,
  Mail,
  Send
} from "lucide-react";

// Types based on your schema
interface StudentGroup {
  groupId: number;
  groupUsername: string;
  groupPass: string | null;
  leaderEmail: string;
  supervisorEmail: string;
  status: 'PENDING' | 'VERIFIED' | 'DENIED';
  projectTitle?: string;
  domain?: string;
  juryId: number;
  members: [];
}

interface Student {
  stdId: number;
  name: string;
  email: string;
  rollNum: string;
  section: string;
  batch: number;
  groupId: number;
  status: 'PENDING' | 'ACTIVE';
}

interface Department {
  deptId: number;
  name: string;
}

interface Teacher {
  TeacherId: number;
  name: string;
  email: string;
  department: string;
  specialization: string;
}

type TabType = 'pending' | 'verified' | 'departments' | 'teachers' | 'students';
interface StudentGroup {
  groupId: number;
  groupUsername: string;
  // ... other properties
}

// ============================================
// MODAL COMPONENTS (OUTSIDE THE MAIN COMPONENT)
// ============================================

// Department Modal - This is OUTSIDE AdminDashboard
interface DepartmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (name: string) => void;
}

const DepartmentModalComponent = ({ isOpen, onClose, onSave }: DepartmentModalProps) => {
  const [name, setName] = useState("");

  useEffect(() => {
    if (isOpen) {
      setName("");
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg w-full max-w-md p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">Add Department</h3>
          <button onClick={onClose}>
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Department Name</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full px-3 py-2 border border-gray-200 rounded-lg"
            placeholder="e.g., Computer Science"
            autoFocus
          />
        </div>
        <div className="flex justify-end gap-3 mt-6">
          <button onClick={onClose} className="px-4 py-2 border border-gray-300 rounded-lg">Cancel</button>
          <button onClick={() => onSave(name)} className="px-4 py-2 bg-[#3F51B5] text-white rounded-lg">Add</button>
        </div>
      </div>
    </div>
  );
};

// Teacher Modal - This is OUTSIDE AdminDashboard
interface TeacherModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (teacher: any) => void;
  departments: any[];
}

const TeacherModalComponent = ({ isOpen, onClose, onSave, departments }: TeacherModalProps) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    department: '',
    specialization: '',
    qualification: '',
    experience: '',
    role: 'junior'
  });

  useEffect(() => {
    if (isOpen) {
      setFormData({
        name: '',
        email: '',
        department: '',
        specialization: '',
        qualification: '',
        experience: '',
        role: 'junior'
      });
    }
  }, [isOpen]);

  if (!isOpen) return null;


  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg w-full max-w-2xl p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">Add Teacher</h3>
          <button onClick={onClose}><X className="w-5 h-5 text-gray-400" /></button>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-1">Full Name *</label>
            <input 
              type="text" 
              value={formData.name} 
              onChange={(e) => setFormData({...formData, name: e.target.value})} 
              className="w-full px-3 py-2 border border-gray-200 rounded-lg"
              autoFocus
            />
          </div>
          <div className="col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-1">Email *</label>
            <input 
              type="email" 
              value={formData.email} 
              onChange={(e) => setFormData({...formData, email: e.target.value})} 
              className="w-full px-3 py-2 border border-gray-200 rounded-lg" 
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Department *</label>
            <select 
              value={formData.department} 
              onChange={(e) => setFormData({...formData, department: e.target.value})} 
              className="w-full px-3 py-2 border border-gray-200 rounded-lg"
            >
              <option value="">Select</option>
              {departments.map(dept => <option key={dept.deptId} value={dept.name}>{dept.name }</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Specialization *</label>
            <input 
              type="text" 
              value={formData.specialization} 
              onChange={(e) => setFormData({...formData, specialization: e.target.value})} 
              className="w-full px-3 py-2 border border-gray-200 rounded-lg" 
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Qualification *</label>
            <input 
              type="text" 
              value={formData.qualification} 
              onChange={(e) => setFormData({...formData, qualification: e.target.value})} 
              className="w-full px-3 py-2 border border-gray-200 rounded-lg" 
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Experience (years) *</label>
            <input 
              type="number" 
              value={formData.experience} 
              onChange={(e) => setFormData({...formData, experience: e.target.value})} 
              className="w-full px-3 py-2 border border-gray-200 rounded-lg" 
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Role *</label>
            <select 
              value={formData.role} 
              onChange={(e) => setFormData({...formData, role: e.target.value})} 
              className="w-full px-3 py-2 border border-gray-200 rounded-lg"
            >
              <option value="junior">Junior</option>
              <option value="senior">Senior</option>
            </select>
          </div>
        </div>
        <div className="flex justify-end gap-3 mt-6">
          <button onClick={onClose} className="px-4 py-2 border border-gray-300 rounded-lg">Cancel</button>
          <button onClick={() => onSave(formData)} className="px-4 py-2 bg-[#3F51B5] text-white rounded-lg">Add Teacher</button>
        </div>
      </div>
    </div>
  );
};

export default function AdminDashboard() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<TabType>('pending');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [loading, setLoading] = useState(true);
  
  // Data states
  const [pendingGroups, setPendingGroups] = useState<StudentGroup[]>([]);
  const [verifiedGroups, setVerifiedGroups] = useState<StudentGroup[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  
  // Modal states
  const [showGroupModal, setShowGroupModal] = useState<{show: boolean, group: StudentGroup | null}>({show: false, group: null});
  const [showDepartmentModal, setShowDepartmentModal] = useState(false);
  const [showTeacherModal, setShowTeacherModal] = useState(false);
  const [showCredentials, setShowCredentials] = useState<{show: boolean, group: StudentGroup | null, password: string}>({show: false, group: null, password: ''});
  
  // Form states
  const [departmentForm, setDepartmentForm] = useState({ name: '' });
  const [teacherForm, setTeacherForm] = useState({
    name: '', email: '', department: '', specialization: '', qualification: '', experience: '', role: 'junior'
  });
  
  // Search
  const [searchTerm, setSearchTerm] = useState('');
  
  // Stats
  const [stats, setStats] = useState({
    totalStudents: 0,
    totalTeachers: 0,
    totalDepartments: 0,
    pendingGroups: 0
  });

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (!storedUser) {
      router.push('/login');
      return;
    }
    const parsedUser = JSON.parse(storedUser);
    if (parsedUser.role !== 'ADMIN') {
      router.push('/login');
      return;
    }
    setUser(parsedUser);
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
  setLoading(true);
  try {
    // Fetch pending groups (where status = 'PENDING')
    const pendingRes = await fetch('/api/admin/groups?status=PENDING');
    const pendingData = await pendingRes.json();
    console.log("Groups fetched: ", pendingData);
    setPendingGroups(pendingData);
    
    // Fetch verified groups
    const verifiedRes = await fetch('/api/admin/groups?status=VERIFIED');
    const verifiedData = await verifiedRes.json();
    setVerifiedGroups(verifiedData);
    
    // Fetch departments
    const deptRes = await fetch('/api/admin/departments');
    const deptData = await deptRes.json();
    setDepartments(deptData);
    
    // Fetch teachers
    const teacherRes = await fetch('/api/admin/teachers');
    const teacherData = await teacherRes.json();
    setTeachers(teacherData);
    
    // Fetch students and extract roll number from email
    const studentRes = await fetch('/api/admin/students');
    let studentData = await studentRes.json();
    
    // ✅ Process each student with safety check
    if (Array.isArray(studentData)) {
      studentData = studentData.map((student: any) => {
        // ✅ Check if email exists before calling match
        const email = student?.email || '';
        let rollNumber = '';
        
        if (email && typeof email === 'string') {
          const match = email.match(/k(\d{2})(\d{4})@/);
          if (match) {
            const firstTwo = match[1];  // e.g., "24"
            const lastFour = match[2];   // e.g., "3094"
            rollNumber = `${firstTwo}k-${lastFour}`; // e.g., "24k-3094"
          }
        }
        
        return {
          ...student,
          rollNum: rollNumber
        };
      });
    }
    
    setStudents(studentData);
    
    // ✅ Safely calculate stats
    setStats({
      totalStudents: Array.isArray(studentData) ? studentData.length : 0,
      totalTeachers: Array.isArray(teacherData) ? teacherData.length : 0,
      totalDepartments: Array.isArray(deptData) ? deptData.length : 0,
      pendingGroups: Array.isArray(pendingData) ? pendingData.length : 0
    });
    
  } catch (error) {
    console.error('Error fetching data:', error);
  } finally {
    setLoading(false);
  }
};

  // Approve Group - Generate password and send email
  const handleApproveGroup = async (group: StudentGroup) => {
    // Generate random password
    const generatedPassword = generateRandomPassword();
    
    try {
      const response = await fetch('/api/admin/approve-group', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          groupId: group.groupId, 
          password: generatedPassword 
        })
      });
      
      if (response.ok) {
        // Show credentials modal
        setShowCredentials({ show: true, group, password: generatedPassword });
        fetchDashboardData(); // Refresh data
      }
    } catch (error) {
      console.error('Error approving group:', error);
    }
  };

  // Reject Group
  const handleRejectGroup = async (groupId: number) => {
    if (confirm('Are you sure you want to reject this group?')) {
      try {
        const response = await fetch('/api/admin/reject-group', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ groupId })
        });
        
        if (response.ok) {
          fetchDashboardData();
        }
      } catch (error) {
        console.error('Error rejecting group:', error);
      }
    }
  };

  // Generate random password
  const generateRandomPassword = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let password = '';
    for (let i = 0; i < 8; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return password;
  };

  // View Group Members
  const handleViewGroup = async (group: StudentGroup) => {
    const membersRes = await fetch(`/api/admin/groups/${group.groupId}/members`);
    const members = await membersRes.json();
    setShowGroupModal({ show: true, group: { ...group, members } });
  };

  const handleLogout = () => {
    localStorage.removeItem('user');
    router.push('/login');
  };

  const handleAddTeacher = async (teacherData: any) => {
  try {
    const response = await fetch('/api/admin/teachers', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(teacherData)
    });
    
    if (response.ok) {
      // Refresh the teachers list
      fetchDashboardData();
      // Close the modal
      setShowTeacherModal(false);
    } else {
      const error = await response.json();
      console.error('Error adding teacher:', error);
      // Optionally show error message to user
    }
  } catch (error) {
    console.error('Network error:', error);
  }
};

  // ============================================
  // UI Components
  // ============================================

  const StatCard = ({ title, value, icon: Icon, color }: any) => (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-gray-500 mb-1">{title}</p>
          <p className="text-2xl font-bold text-gray-800">{value}</p>
        </div>
        <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${color}`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
      </div>
    </div>
  );

  const Sidebar = () => (
    <div className={`${sidebarCollapsed ? 'w-20' : 'w-64'} bg-[#1A237E] h-screen fixed left-0 top-0 transition-all duration-300 z-20`}>
      <div className="p-4 border-b border-[#3F51B5]/30">
        <div className="flex items-center justify-between">
          {!sidebarCollapsed && (
            <div>
              <h1 className="text-white font-bold text-lg">FYP Admin</h1>
              <p className="text-[#9FA8DA] text-xs">Dashboard</p>
            </div>
          )}
          <button
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            className="text-[#9FA8DA] hover:text-white transition-colors"
          >
            {sidebarCollapsed ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
          </button>
        </div>
      </div>
      
      <nav className="p-4 space-y-2">
        <button
          onClick={() => setActiveTab('pending')}
          className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
            activeTab === 'pending' ? 'bg-[#3F51B5] text-white' : 'text-[#9FA8DA] hover:bg-[#3F51B5]/20'
          }`}
        >
          <AlertCircle className="w-5 h-5" />
          {!sidebarCollapsed && <span>Pending Groups</span>}
          {!sidebarCollapsed && stats.pendingGroups > 0 && (
            <span className="ml-auto bg-orange-500 text-white text-xs px-2 py-0.5 rounded-full">
              {stats.pendingGroups}
            </span>
          )}
        </button>
        
        <button
          onClick={() => setActiveTab('verified')}
          className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
            activeTab === 'verified' ? 'bg-[#3F51B5] text-white' : 'text-[#9FA8DA] hover:bg-[#3F51B5]/20'
          }`}
        >
          <CheckCircle className="w-5 h-5" />
          {!sidebarCollapsed && <span>Verified Groups</span>}
        </button>
        
        <button
          onClick={() => setActiveTab('departments')}
          className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
            activeTab === 'departments' ? 'bg-[#3F51B5] text-white' : 'text-[#9FA8DA] hover:bg-[#3F51B5]/20'
          }`}
        >
          <BookOpen className="w-5 h-5" />
          {!sidebarCollapsed && <span>Departments</span>}
        </button>
        
        <button
          onClick={() => setActiveTab('teachers')}
          className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
            activeTab === 'teachers' ? 'bg-[#3F51B5] text-white' : 'text-[#9FA8DA] hover:bg-[#3F51B5]/20'
          }`}
        >
          <Users className="w-5 h-5" />
          {!sidebarCollapsed && <span>Teachers</span>}
        </button>
        
        <button
          onClick={() => setActiveTab('students')}
          className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
            activeTab === 'students' ? 'bg-[#3F51B5] text-white' : 'text-[#9FA8DA] hover:bg-[#3F51B5]/20'
          }`}
        >
          <GraduationCap className="w-5 h-5" />
          {!sidebarCollapsed && <span>Students</span>}
        </button>
      </nav>
      
      <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-[#3F51B5]/30">
        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-[#9FA8DA] hover:bg-red-500/20 hover:text-red-300 transition-colors"
        >
          <LogOut className="w-5 h-5" />
          {!sidebarCollapsed && <span>Logout</span>}
        </button>
      </div>
    </div>
  );
  
  // ============================================
// Students Tab
// ============================================
// ============================================
// Verified Groups Tab
// ============================================
const VerifiedGroupsTab = () => (
  <div className="space-y-4">
    {verifiedGroups.length === 0 ? (
      <div className="bg-white rounded-lg shadow p-8 text-center">
        <CheckCircle className="w-12 h-12 text-gray-400 mx-auto mb-3" />
        <h3 className="text-lg font-medium text-gray-800">No Verified Groups</h3>
        <p className="text-gray-500">No groups have been verified yet.</p>
      </div>
    ) : (
      verifiedGroups.map((group) => (
        <div key={group.groupId} className="bg-white rounded-lg shadow-md border border-gray-100 overflow-hidden">
          <div className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-semibold text-gray-800 text-lg">{group.groupUsername}</h3>
                <p className="text-sm text-gray-500">Leader: {group.leaderEmail}</p>
                <p className="text-sm text-gray-500">Supervisor: {group.supervisorEmail}</p>
                <p className="text-sm text-green-600 mt-1 flex items-center gap-1">
                  <CheckCircle className="w-4 h-4" />
                  Verified
                </p>
              </div>
              <button
                onClick={() => handleViewGroup(group)}
                className="px-3 py-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm"
              >
                View Details
              </button>
            </div>
          </div>
        </div>
      ))
    )}
  </div>
);

// ============================================
// Departments Tab
// ============================================
const DepartmentsTab = () => (
  <div className="bg-white rounded-lg shadow overflow-hidden">
    <table className="w-full">
      <thead className="bg-gray-50">
        <tr>
          <th className="text-left p-4 font-medium text-gray-600">ID</th>
          <th className="text-left p-4 font-medium text-gray-600">Department Name</th>
          <th className="text-left p-4 font-medium text-gray-600">Actions</th>
        </tr>
      </thead>
      <tbody>
        {departments.length === 0 ? (
          <tr>
            <td colSpan={3} className="text-center p-8 text-gray-500">
              No departments found. Click "Add Department" to create one.
            </td>
          </tr>
        ) : (
          departments.map((dept) => (
            <tr key={dept.deptId} className="border-t border-gray-100 hover:bg-gray-50">
              <td className="p-4">{dept.deptId}</td>
              <td className="p-4 font-medium">{dept.name}</td>
              <td className="p-4">
                <button onClick={()=>deleteDepartment(dept.deptId)} className="text-red-600 hover:text-red-800">
                  <Trash2 className="w-4 h-4" />
                </button>
              </td>
            </tr>
          ))
        )}
      </tbody>
    </table>
  </div>
);

// ============================================
// Teachers Tab
// ============================================
const TeachersTab = () => (
  <div className="bg-white rounded-lg shadow overflow-hidden">
    <table className="w-full">
      <thead className="bg-gray-50">
        <tr>
          <th className="text-left p-4 font-medium text-gray-600">ID</th>
          <th className="text-left p-4 font-medium text-gray-600">Name</th>
          <th className="text-left p-4 font-medium text-gray-600">Email</th>
          <th className="text-left p-4 font-medium text-gray-600">Department</th>
          <th className="text-left p-4 font-medium text-gray-600">Specialization</th>
        </tr>
      </thead>
      <tbody>
        {teachers.length === 0 ? (
          <tr>
            <td colSpan={5} className="text-center p-8 text-gray-500">
              No teachers found. Click "Add Teacher" to create one.
            </td>
          </tr>
        ) : (
          teachers.map((teacher) => (
            <tr key={teacher.TeacherId} className="border-t border-gray-100 hover:bg-gray-50">
              <td className="p-4">{teacher.TeacherId}</td>
              <td className="p-4 font-medium">{teacher.name}</td>
              <td className="p-4 text-gray-500">{teacher.email}</td>
              <td className="p-4">{teacher.department}</td>
              <td className="p-4">{teacher.specialization}</td>
            </tr>
          ))
        )}
      </tbody>
    </table>
  </div>
);

// ============================================
// Students Tab
// ============================================
const StudentsTab = () => (
  <div className="bg-white rounded-lg shadow overflow-hidden">
    <table className="w-full">
      <thead className="bg-gray-50">
        <tr>
          <th className="text-left p-4 font-medium text-gray-600">ID</th>
          <th className="text-left p-4 font-medium text-gray-600">Name</th>
          <th className="text-left p-4 font-medium text-gray-600">Roll No</th>
          <th className="text-left p-4 font-medium text-gray-600">Email</th>
          <th className="text-left p-4 font-medium text-gray-600">Section</th>
          <th className="text-left p-4 font-medium text-gray-600">Batch</th>
        </tr>
      </thead>
      <tbody>
        {students.length === 0 ? (
          <tr>
            <td colSpan={6} className="text-center p-8 text-gray-500">
              No students found.
            </td>
          </tr>
        ) : (
          students.map((student) => (
            <tr key={student.stdId} className="border-t border-gray-100 hover:bg-gray-50">
              <td className="p-4">{student.stdId}</td>
              <td className="p-4 font-medium">{student.name}</td>
              <td className="p-4">{student.rollNum}</td>
              <td className="p-4 text-gray-500">{student.email}</td>
              <td className="p-4">{student.section}</td>
              <td className="p-4">{student.batch}</td>
            </tr>
          ))
        )}
      </tbody>
    </table>
  </div>
);

// ============================================
// Add Department Handler
// ============================================
const handleAddDepartment = async () => {
  try {
    const response = await fetch('/api/admin/departments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: departmentForm.name })
    });
    
    if (response.ok) {
      fetchDashboardData();
      setShowDepartmentModal(false);
      setDepartmentForm({ name: '' });
    }
  } catch (error) {
    console.error('Error adding department:', error);
  }
};

const deleteDepartment = async (id: Number) => {
  try {
    const response = await fetch('/api/admin/departments/delete',{
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({deptId: id})
    });
    if(response.ok){
      fetchDashboardData();
      console.log("Department deleted");  
    }
  } catch (error) {
    console.error("Error deleting department: ",error);
  }
}

  // ============================================
  // Pending Groups Tab
  // ============================================
  const PendingGroupsTab = () => (
    <div className="space-y-4">
      {pendingGroups.length === 0 ? (
        <div className="bg-white rounded-lg shadow p-8 text-center">
          <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-3" />
          <h3 className="text-lg font-medium text-gray-800">No Pending Groups</h3>
          <p className="text-gray-500">All groups have been reviewed.</p>
        </div>
      ) : (
        pendingGroups.map((group) => (
          <div key={group.groupId} className="bg-white rounded-lg shadow-md border border-gray-100 overflow-hidden">
            <div className="p-6">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-semibold text-gray-800 text-lg">{group.groupUsername}</h3>
                  <p className="text-sm text-gray-500">Leader: {group.leaderEmail}</p>
                  <p className="text-sm text-gray-500">Supervisor: {group.supervisorEmail}</p>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleViewGroup(group)}
                    className="px-3 py-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm"
                  >
                    View Details
                  </button>
                  <button
                    onClick={() => handleApproveGroup(group)}
                    className="px-3 py-1.5 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm flex items-center gap-1"
                  >
                    <CheckCircle className="w-4 h-4" />
                    Approve
                  </button>
                  <button
                    onClick={() => handleRejectGroup(group.groupId)}
                    className="px-3 py-1.5 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors text-sm flex items-center gap-1"
                  >
                    <XCircle className="w-4 h-4" />
                    Reject
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))
      )}
    </div>
  );

  // ============================================
  // Credentials Modal
  // ============================================
  const CredentialsModal = () => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg w-full max-w-md p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">Group Credentials</h3>
          <button onClick={() => setShowCredentials({ show: false, group: null, password: '' })}>
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>
        
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
          <p className="text-green-800 text-sm flex items-center gap-2">
            <Mail className="w-4 h-4" />
            Credentials have been sent to {showCredentials.group?.leaderEmail}
          </p>
        </div>
        
        <div className="space-y-3">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Group Username</label>
            <input
              type="text"
              value={showCredentials.group?.groupUsername || ''}
              readOnly
              className="w-full px-3 py-2 border border-gray-200 rounded-lg bg-gray-50"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
            <div className="relative">
              <input
                type="text"
                value={showCredentials.password}
                readOnly
                className="w-full px-3 py-2 border border-gray-200 rounded-lg bg-gray-50 font-mono"
              />
            </div>
            <p className="text-xs text-gray-500 mt-1">Please share these credentials with the group leader.</p>
          </div>
        </div>
        
        <button
          onClick={() => setShowCredentials({ show: false, group: null, password: '' })}
          className="w-full mt-6 px-4 py-2 bg-[#3F51B5] text-white rounded-lg hover:bg-[#5C6BC0]"
        >
          Close
        </button>
      </div>
    </div>
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-[#3F51B5] border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }


 return (
  <div className="min-h-screen bg-gray-50">
    <Sidebar />
    
    <div className={`${sidebarCollapsed ? 'ml-20' : 'ml-64'} transition-all duration-300`}>
      {/* Top Bar */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold text-gray-800">
            {activeTab === 'pending' && 'Pending Groups'}
            {activeTab === 'verified' && 'Verified Groups'}
            {activeTab === 'departments' && 'Departments'}
            {activeTab === 'teachers' && 'Teachers'}
            {activeTab === 'students' && 'Students'}
          </h2>
          
          {/* Add buttons for departments and teachers */}
          {(activeTab === 'departments' || activeTab === 'teachers') && (
            <button
              onClick={() => activeTab === 'departments' ? setShowDepartmentModal(true) : setShowTeacherModal(true)}
              className="bg-[#3F51B5] hover:bg-[#5C6BC0] text-white px-4 py-2 rounded-lg text-sm flex items-center gap-2 transition-colors"
            >
              <Plus className="w-4 h-4" />
              Add {activeTab === 'departments' ? 'Department' : 'Teacher'}
            </button>
          )}
          
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 pr-3 py-1.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#3F51B5] w-64"
            />
          </div>
        </div>
      </div>
      
      {/* Stats Cards */}
      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          <StatCard title="Total Students" value={stats.totalStudents} icon={GraduationCap} color="bg-blue-500" />
          <StatCard title="Total Teachers" value={stats.totalTeachers} icon={Users} color="bg-green-500" />
          <StatCard title="Departments" value={stats.totalDepartments} icon={BookOpen} color="bg-purple-500" />
          <StatCard title="Pending Groups" value={stats.pendingGroups} icon={AlertCircle} color="bg-orange-500" />
        </div>
        
        {/* Main Content - ALL TABS */}
        {activeTab === 'pending' && <PendingGroupsTab />}
        {activeTab === 'verified' && <VerifiedGroupsTab />}
        {activeTab === 'departments' && <DepartmentsTab />}
        {activeTab === 'teachers' && <TeachersTab />}
        {activeTab === 'students' && <StudentsTab />}
      </div>
    </div>
    
    {/* Modals */}
    {showDepartmentModal && <DepartmentModalComponent 
        isOpen={showDepartmentModal}
        onClose={() => setShowDepartmentModal(false)}
        onSave={handleAddDepartment}
      />
      }
    {showTeacherModal && <TeacherModalComponent 
        isOpen={showTeacherModal}
        onClose={() => setShowTeacherModal(false)}
        onSave={handleAddTeacher}
        departments={departments}
      />}
    {showCredentials.show && <CredentialsModal />}
  </div>
);
}


