import { NextResponse, NextRequest } from "next/server";
import { executeQuery } from "@/app/lib/db";

export async function GET(req: NextRequest){
    try {
       const teachers = await executeQuery('SELECT * FROM TEACHERS');
       return NextResponse.json(teachers);
    } catch (error) {
        return NextResponse.json({message: 'Error in geting teachers'},{status: 500})
    }
}

export async function POST(req: NextRequest) {
    try {
        const body = await req.json();
        const { name, email, department, specialization, qualification, experience, role } = body;

        // ✅ Validate required fields
        if (!name || !email || !department) {
            return NextResponse.json(
                { message: 'Name, email, and department are required' },
                { status: 400 }
            );
        }

        // ✅ Check for duplicate teacher (by email or name)
        const existingTeacher = await executeQuery(
            'SELECT TEACHERID, NAME, EMAIL FROM TEACHERS WHERE EMAIL = ? OR NAME = ?',
            [email, name]
        );

        if (Array.isArray(existingTeacher) && existingTeacher.length > 0) {
            const existing = (existingTeacher as any[])[0];
            const conflictField = existing.EMAIL === email ? 'Email' : 'Name';
            return NextResponse.json(
                { message: `${conflictField} already exists. Teacher already registered.` },
                { status: 400 }
            );
        }

        // ✅ Fetch department ID
        const dept = await executeQuery(
            'SELECT DEPTID FROM DEPARTMENTS WHERE NAME = ?',
            [department]
        );

        const deptId = (dept as any[])[0]?.DEPTID;

        if (!deptId) {
            return NextResponse.json(
                { message: 'Invalid department. Department not found.' },
                { status: 400 }
            );
        }

        // ✅ Generate password (you can make this more secure)
        const password = `${name.replace(/\s/g, '')}_123`; // Remove spaces from name

        // ✅ Add teacher
        const result = await executeQuery(
            `INSERT INTO TEACHERS 
             (EMAIL, USERNAME, NAME, PASSWORD, SPECIALIZATION, QUALIFICATION, EXPERIENCE, ROLE, DEPTID) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [email, email, name, password, specialization, qualification, experience, role, deptId]
        );

        // ✅ Get the new teacher ID
        const newTeacherId = (result as any).insertId;

        // ✅ Send success response
        return NextResponse.json({
            success: true,
            message: 'Teacher added successfully',
            teacherId: newTeacherId,
            credentials: {
                email: email,
                username: email,
                password: password
            }
        }, { status: 201 });

    } catch (error) {
        console.error('Error adding teacher:', error);
        return NextResponse.json(
            { message: 'Error in adding teacher!', error: (error as Error).message },
            { status: 500 }
        );
    }
}